# flutter_rest_app

Aplicação Flutter que consome a API pública JSONPlaceholder com arquitetura em camadas (modelo, serviço e UI).

## Como rodar

```bash
flutter pub get
flutter run
```

## Estrutura

- `lib/models/post.dart`: modelo `Post` com `fromJson`/`toJson`.
- `lib/services/post_service.dart`: serviço `PostService` com métodos `fetchPosts` (GET) e `createPost` (POST).
- `lib/main.dart`: UI com `FutureBuilder` e lista de posts.

## Observações

- Certifique-se de ter a permissão `android.permission.INTERNET` no Android (projetos recentes já incluem por padrão).
- A API JSONPlaceholder retorna dados de teste; o `POST` não persiste, mas responde com um JSON simulado.
